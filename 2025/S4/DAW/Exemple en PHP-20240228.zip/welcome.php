<html>
<body>
<?php
$nom=$_POST["name"];
$email=$_POST["email"];
echo "Welcome"." ". $nom. "<br>";
echo "Your email address is:"." ".$email; 

include ("insertion.php");?>

<a href="afficher.php"> afficher </a>
</body>
</html>