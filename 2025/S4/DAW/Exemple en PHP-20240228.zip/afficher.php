<?php
// Create connection
$conn = mysql_connect("localhost", "root", "");
// Check connection
if (!$conn) {
  die("Connection failed: " . mysql_error());
}
mysql_select_db("Ma base");

$sql = 'SELECT nom,email,siteweb,commentaire,genre FROM table1';

// on envoie la requête
$req = mysql_query($sql) or die('Erreur SQL !<br>'.$sql.'<br>'.mysql_error());

// on fait une boucle qui va faire un tour pour chaque enregistrement
while($data = mysql_fetch_assoc($req))
    {
    // on affiche les informations de l'enregistrement en cours
    echo '<b>'.$data['nom'].' '.$data['email'].'</b> ('.$data['siteweb'].')';
    echo ' <i>genre : '.$data['genre'].'</i><br>';
    }
