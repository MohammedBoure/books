<?php
// Create connection
$conn = mysql_connect("localhost", "root", "");
// Check connection
if (!$conn) {
  die("Connection failed: " . mysql_error());
}
mysql_select_db("Ma base");
$nom=$_POST["name"];
$email=$_POST["email"];
$siteweb=$_POST["website"];
$commentaire=$_POST["comment"];
$genre=$_POST["gender"];

$sql = "INSERT INTO table1 (nom, email, siteweb, commentaire, genre)
VALUES ('$nom', '$email', '$siteweb', '$commentaire', '$genre')";

if (mysql_query($sql)) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . mysql_error($conn);
}

/* mysql_close(); */
?>
